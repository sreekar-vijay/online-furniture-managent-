<?php
include("header.php");
?>

<!-- about -->
<div class="about" id="about">
	<div class="container">
		<div class="w3-about-grid-top">
			<div class="w3-agileits-about-grids">
					<div class="col-md-4 agile-about-left">
						<div class="w3-about-border">
						<h3>About</h3>
						
						</div>
					
					</div>
					<div class="col-md-8 agile-about-right">
							<div class="w3l-banner-grids">
								<div class="slider">
									<div class="callbacks_container">
										<ul class="rslides" id="slider4">
										<li>
											<div class="w3ls-text">
												<h3>ONLINE FURNITURE STORE</h3>
												<p>We believe that great design is for everyone. It surprises, tells a story and makes the everyday a little less ordinary.Here we design for how people live today. No champagne, no private view, just affordable high-end design at your fingertips.<span> On the premises is a team of sales staff that help you in shortlisting from their furniture range according to your needs and requirements. You can conveniently pay for your purchase at this shop using Cash, Master Card, Visa Card, Debit Cards, American Express Card, Credit Card.</span></p>
												
											</div>
										</li>
										<li>
										<div class="w3ls-text">
											<h3>ONLINE FURNITURE STORE</h3>
											<p> In the business for years, this enterprise is one of the prominent points-of-sale in the city for buying fancy and stylish furniture pieces.<span> It features a product range that is sync with the accepted trends and styles in interior décor and design.</span></p>
										</div>
										</li>
										<li>
										<div class="w3ls-text">
											<h3>Services offered by ONLINE FURNITURE STORE & Interiors</h3>
											<p>For decorating your home, you can select from a variety of elegantly crafted wooden almirahs, center tables, cottz beds, dining tables, diwan-cum-beds, foam diwans, sofa sets and dining tables. You can shop for a wide range of office furniture such as executive chairs.  <span>This establishment is also into designing, installing and support services for modular kitchens through kitchen-by-design service. On the premises is a team of sales staff that help you in shortlisting from their furniture range according to your needs and requirements.</span></p>
	
										</div>
										</li>
																		
									</ul>
								</div>
								<script src="js/responsiveslides.min.js"></script>
								<script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider4").responsiveSlides({
									auto: true,
									pager:true,
									nav:false,
									speed: 500,
									namespace: "callbacks",
									before: function () {
									  $('.events').append("<li>before event fired.</li>");
									},
									after: function () {
									  $('.events').append("<li>after event fired.</li>");
									}
								  });
							
								});
							 </script>
							<!--banner Slider starts Here-->
								</div>
							</div>

					</div>
					<div class="clearfix"> </div>
			</div>
		</div>
	</div>
 </div>
	<!-- //about -->
<!-- services -->
 <div class="services" id="services">
		<div class="container">
			<div class="ser-top wthree-3 wow fadeInDown w3-service-head">
				<h3>Our Services </h3>
			</div>
			<div class="w3-service-grids set-6">
				<div class="col-md-4  services-w3-grid1 ser-left wow fadeInDown icon1 hi-icon-wrap hi-icon-effect-6">
					<span class="glyphicon glyphicon-home hi-icon hi-icon-home" aria-hidden="true"></span>
					<h4>Quick Delivery </h4>
					<p>We try to deliver the product as per the given delivery time.We assure quick delivery of the product.</p>
				</div>
				<div class="col-md-4  services-w3-grid1 ser-left wow fadeInDown icon2 hi-icon-wrap hi-icon-effect-6">
					<span class="glyphicon glyphicon-sort-by-attributes hi-icon hi-icon-sort-by-attributes" aria-hidden="true"></span>
					<h4>Variety</h4>
					<p>We provide wide range of products with variety in models and designs.</p>
				</div>
				<div class="col-md-4 services-w3-grid1 ser-left wow fadeInDown icon3 hi-icon-wrap hi-icon-effect-6">
					<span class="glyphicon glyphicon-object-align-vertical hi-icon hi-icon-object-align-vertical" aria-hidden="true"></span>
					<h4>blandit ornare</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum Lorem ipsum velit vestibulum velit.</p>
				</div>
				<div class="col-md-4 services-w3-grid2 ser-left wow fadeInDown icon4 hi-icon-wrap hi-icon-effect-6">
					<span class="glyphicon glyphicon-send hi-icon hi-icon-send" aria-hidden="true"></span>
					<h4>imperdiet pretium </h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum Lorem ipsum velit vestibulum velit.</p>
				</div>
				<div class="col-md-4 services-w3-grid2 ser-left wow fadeInDown icon5 hi-icon-wrap hi-icon-effect-6">
					<span class="glyphicon glyphicon-briefcase hi-icon hi-icon-briefcase" aria-hidden="true"></span>
					<h4>Aliquam erat</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum velit Lorem ipsum vestibulum velit.</p>
				</div>
				<div class="col-md-4 services-w3-grid2 ser-left wow fadeInDown icon6 hi-icon-wrap hi-icon-effect-6"  data-wow-duration=".8s" data-wow-delay=".2s">
					<span class="glyphicon glyphicon-time hi-icon hi-icon-time" aria-hidden="true"></span>
					<h4>auctor mauris </h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum velit dolor sit amet vestibulum velit.</p>
				</div>
				<div class="clearfix"></div>
			</div>	
		</div>
	</div>
<!-- /services -->

<?php
include("footer.php");
?>
