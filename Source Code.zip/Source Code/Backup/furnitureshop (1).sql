-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2018 at 10:01 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furnitureshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `billingid` int(10) NOT NULL,
  `customerid` int(10) NOT NULL,
  `purchasedate` date NOT NULL,
  `deliverystatus` varchar(25) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `note` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`billingid`, `customerid`, `purchasedate`, `deliverystatus`, `address`, `city`, `state`, `contactno`, `pincode`, `note`, `status`) VALUES
(12, 12, '2018-02-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '652144', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(13, 12, '2018-02-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '652144', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(14, 11, '2018-02-05', 'Pending', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(15, 11, '2018-02-06', 'Pending', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(16, 11, '2018-02-06', 'Pending', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(17, 11, '2018-02-07', 'Delivered', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(18, 11, '2018-02-07', 'Delivered', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(20, 11, '2018-02-07', 'Delivered', '3rd floor', 'udupi', 'karnataka', '7894561230', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(21, 12, '2018-02-09', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(22, 13, '2018-02-09', 'Under process', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(23, 13, '2018-02-10', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(24, 13, '2018-02-10', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(25, 13, '2018-02-10', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(26, 13, '2018-02-10', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Tamil Nadu', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(27, 13, '2018-02-10', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Maharastra', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(28, 13, '2018-02-11', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(29, 13, '2018-02-11', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Maharastra', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(30, 13, '2018-02-11', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(31, 13, '2018-02-15', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(32, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(33, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(34, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(35, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(36, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Master card |Card holder raj |Card no 1231231231234124234|expiry Date- 2018-02|CVV No 344', 'Active'),
(37, 13, '2018-02-16', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(38, 13, '2018-02-21', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(39, 13, '2018-02-21', 'Pending', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(40, 12, '2018-02-21', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Debit card |Card holder raj |Card no 234234234|expiry Date- 2018-02|CVV No 343', 'Active'),
(41, 12, '2018-02-21', 'Delivered', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Debit card |Card holder 2424234234 |Card no 345345345|expiry Date- 2018-03|CVV No 433', 'Active'),
(42, 13, '2018-02-24', 'Delivered', 'Sunshine Colonny\r\n5th floor\r\nPalimar', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type - Master card |Card holder Raj kiran |Card no 35345345345|expiry Date- 2018-12|CVV No 456', 'Active'),
(43, 13, '2018-02-27', 'Pending', 'Shirva', 'Udupi', 'Karnataka', '85207419631', '574116', 'Payment type -  |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(44, 13, '2018-02-27', 'Pending', 'Shirva', 'Udupi', 'Karnataka', '8520741963', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(45, 13, '2018-02-27', 'Pending', 'Shirva', 'Udupi', 'Karnataka', '8520741963', '574116', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(49, 14, '2018-03-03', 'Pending', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder Raj kiran |Card no 123123123123123345|expiry Date- 2018-01|CVV No 456', 'Active'),
(50, 14, '2018-03-03', 'Pending', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder Raj kiran |Card no 123123123123123345|expiry Date- 2018-01|CVV No 456', 'Active'),
(51, 14, '2018-03-03', 'Pending', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder Raj kiran |Card no 123123123123123345|expiry Date- 2018-01|CVV No 456', 'Active'),
(52, 14, '2018-03-03', 'Pending', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder 1343423424234 |Card no 4565464564|expiry Date- 2018-03|CVV No 453', 'Active'),
(53, 14, '2018-03-03', 'Pending', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder 1343423424234 |Card no 4565464564|expiry Date- 2018-03|CVV No 453', 'Active'),
(54, 14, '2018-03-03', 'Delivered', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', '546321', 'Payment type - VISA |Card holder 1343423424234 |Card no 4565464564|expiry Date- 2018-03|CVV No 453', 'Active'),
(55, 12, '2018-03-04', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(56, 12, '2018-03-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(57, 12, '2018-03-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(58, 12, '2018-03-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(59, 12, '2018-03-05', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Andhra Pradesh', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(60, 12, '2018-03-06', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(61, 12, '2018-03-07', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Cash on delivery |Card holder  |Card no |expiry Date- |CVV No ', 'Active'),
(62, 12, '2018-03-07', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Master card |Card holder Raj kiran |Card no 789765465464879|expiry Date- 2018-11|CVV No 548', 'Active'),
(75, 12, '2018-03-07', 'Pending', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', '54036', 'Payment type - Debit card |Card holder Raj kiran |Card no 24234234234234|expiry Date- 2018-03|CVV No 343', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `cutomer`
--

CREATE TABLE `cutomer` (
  `customer_id` int(10) NOT NULL,
  `customername` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `pincode` int(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cutomer`
--

INSERT INTO `cutomer` (`customer_id`, `customername`, `emailid`, `password`, `address`, `city`, `state`, `contactno`, `pincode`, `status`) VALUES
(12, 'Manjula', 'manju@gmail.com', '101', '4th floor\r\nJK Colony', 'Udupi', 'Karnataka', '9875641332', 54036, 'Active'),
(13, 'Mira', 'mira@gmail.com', '101', 'Shirva', 'Udupi', 'Karnataka', '9865471230', 574116, 'Active'),
(14, 'Anushka', 'anu@yahoo.in', '101', 'Prithvi Apartment\r\n3rd floor\r\n', 'Pune', 'Maharastra', '74102365890', 546321, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeid` int(20) NOT NULL,
  `emptype` varchar(10) NOT NULL,
  `empname` varchar(25) NOT NULL,
  `loginid` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employeeid`, `emptype`, `empname`, `loginid`, `password`, `status`) VALUES
(3, '', 'Riya', 'riya@yahoo.com', 'riya', 'Active'),
(4, 'admin', 'Manju', 'manju@gmail.com', '101', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackid` int(10) NOT NULL,
  `furnitureid` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `ratings` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `feedback` text NOT NULL,
  `fbdate` datetime NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedbackid`, `furnitureid`, `customer_id`, `ratings`, `title`, `feedback`, `fbdate`, `status`) VALUES
(2, 19, 12, 4, 'awesome ', 'pritty good', '2018-02-05 23:54:46', 'Active'),
(3, 18, 11, 2, 'ok ok', 'Dont waste your money !!', '2018-02-06 18:40:18', 'Active'),
(4, 20, 12, 4, 'cool!!', 'amazing designs with attractive offers ..Umm I pretty liked it..', '2018-02-09 08:15:58', 'Active'),
(5, 16, 14, 5, 'Coolie !!', 'Amazing experience in viewing and purchasing different attractive furniture at such amazing price ..', '2018-02-09 08:23:26', 'Active'),
(6, 16, 13, 4, 'Pretty good !!', 'Not bad !! But I just hope that I get to view more amazing designs which is quite unique here !!', '2018-02-09 08:25:36', 'Active'),
(7, 16, 13, 3, 'Arggg!!!!', 'Plzz guys upload some more attractive designs and models ..I wanna see more ', '2018-02-09 08:27:01', 'Active'),
(8, 17, 13, 5, 'Wow !!!', 'Lovely products.. Amazing', '2018-02-09 08:28:28', 'Active'),
(9, 18, 13, 2, 'Rocky', 'not much impressive', '2018-02-09 08:29:59', 'Active'),
(10, 21, 13, 4, 'Coolie !!', 'nice !!', '2018-02-09 14:53:26', 'Active'),
(11, 21, 13, 4, 'Coolie !!', 'nice !!', '2018-02-09 14:55:15', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `furniture`
--

CREATE TABLE `furniture` (
  `furnitureid` int(10) NOT NULL,
  `furnituretypeid` int(10) NOT NULL,
  `supplierid` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `cost` float(10,2) NOT NULL,
  `specifications` text NOT NULL,
  `warranty` text NOT NULL,
  `installationdemo` text NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `furniture`
--

INSERT INTO `furniture` (`furnitureid`, `furnituretypeid`, `supplierid`, `title`, `description`, `cost`, `specifications`, `warranty`, `installationdemo`, `status`) VALUES
(16, 6, 12, 'Woodness Glass 6 Seater Dining Set ', 'Table Top Material: Glass\r\nChair Frame: Metal\r\nUpholstery Included\r\nTable (W x H x D): 120 cm x 75 cm x 70 cm (2 ft 5 in x 3 ft 11 in x 2 ft 3 in)', 13000.00, 'Brand:Woodness\r\nNumber of Benches:0\r\nNumber of Chairs:6\r\nFinish Type:Matte', '1', 'nop', 'Active'),
(17, 5, 12, 'Home Edge Bellance Solid Wood King Bed', 'Material Subtype: Rosewood (Sheesham)\r\nW x H x D: 190 cm x 11.43 cm x 20.5 cm (6 ft 2 in x 4 in x 8 in)\r\nKnock Down - Delivered in non-assembled pieces, installation by service partner', 30000.00, 'Sales Package\r\n1 Bed\r\nModel Number\r\nHEBED781_1\r\nModel Series Name\r\nBellance\r\nBed Size\r\nKing\r\nDelivery Condition\r\nKnock Down\r\nPrimary Color\r\nMulticolor', '1 years', 'yes!! Free installation demo ...', 'Active'),
(18, 6, 12, 'Rubber Wood 6 Seater Dining Set', 'Table Top Material: Engineered Wood\r\nChair Frame: Fabric\r\nUpholstery Included\r\nTable (W x H x D): 145 cm x 74 cm x 84 cm (2 ft 5 in x 4 ft 9 in x 2 ft 9 in)\r\nKnock Down - Delivered in non-assembled pieces,', 14000.00, 'Brand\r\nPerfect Homes by Flipkart\r\nNumber of Benches\r\n0\r\nNumber of Chairs\r\n6\r\nFinish Type\r\nVeneer', '9 months warranty only...', ' installation by service partner', 'Active'),
(19, 7, 13, 'RoyalOak', 'Material: Fabric\r\n1 Reclining Positions\r\nKnock Down\r\nFilling Material: PU Foam\r\nCushion\r\nW x H x D: 203 cm x 102 cm x 86 cm (6 ft 7 in x 3 ft 4 in x 2 ft 9 in)', 32000.00, 'Seating Capacity:\r\n3 Seater\r\nStyle:\r\nContemporary & Modern\r\nSuitable For:\r\nLiving Room', 'no', 'Free installation and demo', 'Active'),
(20, 8, 12, 'Italian wardrobe with sliding doors', 'Width x Height: 127 cm x 183 cm (4 ft 2 in x 6 ft)\r\n3 Doors, 10 Shelves\r\nDoor Type: Hinged Door\r\nKnock Down - Delivered in non-assembled pieces, installation ', 44000.00, 'Brand:HomeTown\r\nDoor Type:Hinged Door\r\nStyle:Contemporary & Modern\r\nFinish Type:Matte', '2', 'yes', 'Active'),
(21, 9, 11, 'The Attic Solid Wood Free Standing Chest of Drawers ', 'Each of the Solid Wood Furniture is hand crafted by the finest artisans from Jodhpur. Wood grain, color variance, texture changes and knots are all part of the charm of the product', 18200.00, 'Brand\r\nThe Attic\r\nModel Number\r\nKL-1774\r\nType\r\nChest of Drawers', ' 2 years', 'Installation and Demo Not required', 'Active'),
(22, 9, 13, 'modernalise', 'nil', 12000.00, 'nil', '1 year warranty', 'Free installation Demo', 'Active'),
(23, 9, 11, 'Woodness Engineered Wood', 'awesome', 12000.00, 'awesome', '1 year', 'Installation and demo for this product is done free of cost as part of this purchase.', 'Active'),
(24, 5, 13, 'FurnitureKraft ', 'Material Subtype: Wrought Iron\r\nW x H x D: 158.8 cm x 70.5 cm x 205.8 cm (5 ft 2 in x 2 ft 3 in x 6 ft 9 in)', 4499.00, 'Sales Package\r\n1 Queen Bed\r\nModel Number\r\nFK/DB/3143 Q\r\nModel Series Name\r\nPalermo\r\nStyle Code\r\nPalermo\r\nBed Size\r\nQueen\r\nDelivery Condition\r\nKnock Down\r\nPrimary Color\r\nBlack\r\nSuitable For\r\nBedroom\r\nStorage Included\r\nNo\r\nWith Mattress\r\nNo', '2 Year Domestic Warranty ', 'Free Installation and Demo', 'Active'),
(25, 10, 12, 'DeckUp Engineered Wood Shoe Rack', 'With this splendidly designed shoe rack, you can now keep all your favourite pairs of shoes in one place and keep your home neat and organised. This shoe rack is quite spacious and has 3 shelves with doors to hide away your shoes in style. The wooden shoe stand is available in wenge with matte finish.', 4999.00, 'Brand\r\nDeckUp\r\nModel Number\r\nBei\r\nColor\r\nBrown\r\nType\r\nShoe Rack\r\nMaterial\r\nEngineered Wood\r\nNumber of Shoe Pairs\r\n16', '10 day warranty on manufacturing defects only ', 'installation and demonot required for this product', 'Active'),
(26, 10, 11, 'HomeTown Imperia Engineered Wood Shoe Rack', 'Material Description\r\nFurniture made of wood is resilient and strong. It is naturally beautiful and also highly durable. Wooden furniture is also weather-resistant and easy to maintain.\r\n\r\nCare Instruction\r\nWipe it clean with a dry cloth. Do not use water.', 4999.00, 'Brand:HomeTown\r\nModel Name:Imperia\r\nShade:Wenge\r\nColor:Brown\r\nType:Shoe Rack\r\nMaterial:Engineered Wood', '1 Year  Warranty', 'Its done free of cost', 'Active'),
(27, 10, 13, 'Urban Influence  Shoe Rack', 'Exellent solution for shoe storage from urban INFLUENCE. Made of engineeered wood Pre lam chip Board in lamination & can take in small space. 24 pairs for ladies/ 18 pairs for Men', 4500.00, 'Type:Shoe Rack\r\nMaterial:Engineered Wood\r\nMaterial Subtype:Particle Board', '10 day warranty on manufacturing defects only ', 'Not required', 'Active'),
(28, 5, 15, 'FurnitureKraft ', 'Material Subtype: Wrought Iron\r\nW x H x D: 158.8 cm x 70.5 cm x 205.8 cm (5 ft 2 in x 2 ft 3 in x 6 ft 9 in)', 5000.00, 'Suitable for:Bed rooms\r\nColor:brown', '1 year warranty', 'Free installation Demo', 'Active'),
(29, 5, 11, 'Engineered Wood bed', 'Material Subtype: Wrought Iron\r\nW x H x D: 158.8 cm x 70.5 cm x 205.8 cm (5 ft 2 in x 2 ft 3 in x 6 ft 9 in)', 5000.00, 'Suitable for:Bed rooms\r\nPrimary color:Black\r\nMaterial used: Wood', '1 year', 'Free installation Demo', 'Active'),
(30, 7, 0, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', ''),
(31, 7, 0, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', 'Customized'),
(32, 7, 13, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', 'Customized'),
(33, 7, 13, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', 'Customized'),
(34, 7, 13, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', 'Customized'),
(35, 7, 13, 'Godrej record', 'godrej description', 5000.00, 'Hi ', '5', '', 'Customized'),
(36, 6, 12, 'Dinning set required', 'Welcome to\r\nSathya Furniture World (Brand Of Sathya)\r\nThe foundation stone of \"Sathya Furniture World\", was laid in the year 1968 and since then we have been manufacturing, supplying and trading Furnishing Products. We are the provider of whole ranges of furniture which also includes Steel Storage, Filing Cabinet, and Personal Lockers. While manufacturing this range of products we do consider the customerâ€™s requirements and need and accordingly we design these products. Our products can be used in the home, workplace, hospitals, organizations, as it an ideal choice for storage of household items, office files and other necessary items. We manufacture wooden, steel products of very high and finer quality which makes them reliable and durable. \r\n\r\nOur main focus in the firm is to bring our customers a product which not has a superior quality, but is also available in a variety of designs which they can choose from. Our products are spacious, corrosion free and termite free. The materials used for the manufacturing of these products are borrowed from a certified vendor and all the material are quality checked. After these products are manufactured, before being supplied, are nicely packaged so that they are scratch proof. Owing to these aspects, we have attained extensive customer base to serve with uttermost gratifications.', 500.00, 'test niote record', '10', '', 'Customized'),
(37, 0, 0, '', 'aa', 0.00, '', '12', '', ''),
(38, 0, 0, '', 'aa', 0.00, '', '12', '', ''),
(39, 0, 0, 'hi', 'ge', 0.00, '', '5', '', ''),
(40, 0, 0, 'hi', 'ge', 0.00, '', '5', '', ''),
(41, 0, 0, 'abcd', 'xyz', 44.00, '', '56', '', ''),
(42, 36, 18, 'abcd', 'xyz', 44.00, '', '56', '', 'Customized'),
(43, 5, 12, 'Queen size bed required', 'we are just testing now', 20000.00, 'this is just a testing process...', '1', '', 'Customized'),
(44, 36, 13, 'Test title', 'test description', 5000.00, '', '50', '', 'Customized'),
(45, 36, 11, 'Test title', 'test description', 5000.00, '', '50', '', 'Customized'),
(51, 36, 15, 'Hello', 'test record here test test record', 40000.00, '', '50', '', 'Customized'),
(52, 7, 14, 'Woodness Engineered Wood', 'Woodness Engineered Wood Woodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered WoodWoodness Engineered Wood', 50000.00, 'TEST RECORD', '1', '', 'Customized'),
(54, 52, 15, 'Woodness Engineered Wood', 'techno', 60000.00, '', '3', '', 'Customized'),
(55, 43, 15, 'Queen size bed ', 'well!! ', 20000.00, '', '15', '', 'Customized'),
(56, 6, 12, 'Test dinning record', 'tet dining description', 50000.00, 'Test note record', '6', '', 'Customized'),
(58, 56, 15, 'Hello furnityre', 'hello description', 50000.00, '', '10', '', 'Customized'),
(59, 7, 12, 'sofa', 'sofa', 787.00, 'test', '2', '', 'Customized'),
(60, 59, 15, 'Woodness Engineered Wood', 'testset', 55000.00, '', '6', '', 'Customized'),
(61, 9, 12, 'Custimize drawer', 'Custimize drawer test record', 80000.00, 'Custimize drawer test record', '25', '', 'Customized'),
(62, 61, 15, 'Drawer customization title', 'drawer customization description', 500000.00, '', '6', '', 'Customized'),
(63, 10, 12, 'Shoe rack customized order title', 'Shoe rack customized order title requiremets', 50000.00, 'Shoe rack customized order title note', '50', '', 'Customized'),
(65, 63, 15, 'Shoe rack reply title', 'Shoe rack reply description', 100000.00, '', '6', '', 'CustomizedBudget');

-- --------------------------------------------------------

--
-- Table structure for table `furnitureimages`
--

CREATE TABLE `furnitureimages` (
  `furnitureimgid` int(10) NOT NULL,
  `furnitureid` int(10) NOT NULL,
  `imgpath` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `furnitureimages`
--

INSERT INTO `furnitureimages` (`furnitureimgid`, `furnitureid`, `imgpath`, `description`, `status`) VALUES
(27, 20, '322images (1).jpg', '', 'Active'),
(30, 17, '179944158bed.jpg', 'amazing', 'Primary'),
(31, 16, '1293705231a5.jpg', '', 'Primary'),
(32, 18, '428105518a2.jpg', '', 'Primary'),
(33, 19, '1421758478live.jpg', '', 'Active'),
(35, 20, '1724596477a9.jpg', '', 'Active'),
(36, 17, '481192623a3.jpg', '', 'Active'),
(37, 17, '1996985714a4.jpg', '', 'Active'),
(38, 17, '2123700290banner77.jpg', '', 'Active'),
(39, 16, '538197180a2.jpg', '', 'Active'),
(40, 18, '370137446gg.jpg', 'Hello test furniture', 'Active'),
(41, 18, '476498289gal4.jpg', '', 'Active'),
(42, 19, '1953915552a1.jpg', '', 'Active'),
(43, 19, '23027799ban5.jpg', '', 'Active'),
(44, 19, '1231424335hi.jpg', '', 'Primary'),
(45, 20, '76649562a10.jpg', '', 'Active'),
(46, 20, '36165391a11.jpg', '', 'Active'),
(47, 20, '1000623295a11.jpg', '', 'Active'),
(48, 20, '797120498download (1).jpg', '', 'Active'),
(49, 20, '421749966download.jpg', '', 'Active'),
(50, 20, '2024922535download.jpg', '', 'Primary'),
(51, 21, '1467044264aaa.jpg', '', 'Primary'),
(52, 21, '828313235a14.jpg', '', 'Active'),
(53, 21, '320081027a13.jpg', '', 'Active'),
(54, 21, '1482378919a12.jpg', '', 'Active'),
(55, 24, '959215184qa.jpeg', '', 'Active'),
(56, 24, '1752138119q1.jpeg', '', 'Active'),
(57, 24, '120319591q2.jpeg', '', 'Primary'),
(59, 0, '1759799124daq.jpeg', '', 'Primary'),
(60, 0, '352294487d.jpg', '', 'Active'),
(61, 0, '1001450301dq.jpeg', '', 'Active'),
(62, 0, '1554323314dq.jpeg', '', 'Active'),
(63, 25, '297316430d.jpg', '', 'Primary'),
(64, 25, '33360011daq.jpeg', '', 'Active'),
(65, 25, '76201506dq.jpeg', '', 'Active'),
(66, 26, '309614570daq.jpeg', '', 'Primary'),
(67, 26, '755529037a7.jpg', '', 'Active'),
(68, 26, '1803732798a8.jpg', '', 'Active'),
(69, 26, '524471945daq.jpeg', '', 'Active'),
(70, 27, '1015021729a8.jpg', '', 'Active'),
(71, 27, '2097930209a7.jpg', '', 'Active'),
(72, 27, '47721829dq.jpeg', '', 'Active'),
(73, 27, '74615679daq.jpeg', '', 'Active'),
(74, 27, '280380188images.jpg', '', 'Primary'),
(75, 28, '578226328a4.jpg', '', 'Primary'),
(76, 28, '293673532a3.jpg', '', 'Active'),
(77, 28, '1217852514gal6.jpg', '', 'Active'),
(78, 29, '2102776285q2.jpeg', '', 'Active'),
(79, 29, '1610840941a3.jpg', '', 'Active'),
(80, 29, '1712407459q2.jpeg', '', 'Primary'),
(81, 29, '2039434932q1.jpeg', '', 'Active'),
(82, 30, '14040109451.png', '', 'Primary'),
(83, 30, '8939608682.png', '', 'Active'),
(84, 35, '1730527924a10.jpg', '', 'Active'),
(85, 36, '548178582a9.jpg', 'ABCD image description', 'Active'),
(86, 43, '1632164655a4.jpg', 'Look ...', 'Active'),
(87, 52, '888439748a10.jpg', 'TEST RECORD', 'Active'),
(88, 56, '17363218661.png', 'Test description', 'Active'),
(89, 59, '1432743745a9.jpg', 'test sofa', 'Active'),
(90, 61, '112633423a10.jpg', 'Customize drawer', 'Active'),
(91, 63, '687719590aaa.jpg', 'Shoe rack customized order title image description', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `furnituretype`
--

CREATE TABLE `furnituretype` (
  `furnituretypeid` int(10) NOT NULL,
  `furnituretype` varchar(50) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `discription` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `furnituretype`
--

INSERT INTO `furnituretype` (`furnituretypeid`, `furnituretype`, `icon`, `discription`, `status`) VALUES
(5, 'Bed', '29733a3.jpg', 'size: King\r\nMaterial Subtype: Rosewood (Sheesham)\r\nW x H x D: 190 cm x 11.43 cm x 20.5 cm (6 ft 2 in x 4 in x 8 in)\r\nKnock Down - Delivered in non-assembled pieces, installation by service partner', 'Active'),
(6, 'Dining set', '27130a2.jpg', 'Table Top Material: Engineered Wood\r\nChair Frame: Fabric\r\nTable (W x H x D): 145 cm x 74 cm x 84 cm (2 ft 5 in x 4 ft 9 in x 2 ft 9 in)\r\nKnock Down - Delivered in non-assembled pieces, installation by service partner.', 'Active'),
(7, 'Sofa', '31659a1.jpg', 'Knock Down\r\nFilling Material: Foam\r\nW x H x D: 0 cm x 0 cm x 0 cm\r\nKnock Down - Delivered in non-assembled pieces, installation by service partner', 'Active'),
(8, 'wardrobe', '25338images.jpg', 'Brand:HomeTown\r\nDoor Type:Hinged Door\r\nStyle:Contemporary & Modern\r\nFinish Type:Matte', 'Active'),
(9, 'Drawer', '1668334857aaa.jpg', 'Width x Height: 900 mm x 950 mm (2 ft 11 in x 3 ft 1 in)', 'Active'),
(10, 'Shoe rack', '1211465850a7.jpg', 'Variety of Shoe racks ', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `messageid` int(10) NOT NULL,
  `customerid` int(10) NOT NULL,
  `supplierid` int(10) NOT NULL,
  `message` text NOT NULL,
  `msgdttim` datetime NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE `offer` (
  `offerid` int(10) NOT NULL,
  `furnitureid` int(10) NOT NULL,
  `supplierid` int(10) NOT NULL,
  `discountamt` float(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offerid`, `furnitureid`, `supplierid`, `discountamt`, `status`) VALUES
(5, 16, 12, 10.00, 'Active'),
(6, 17, 12, 5.00, 'Active'),
(7, 19, 13, 20.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchaseid` int(10) NOT NULL,
  `billingid` int(10) NOT NULL,
  `customerid` int(10) NOT NULL,
  `furnitureid` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `cgsttax` float(10,2) NOT NULL,
  `sgsttax` float(10,2) NOT NULL,
  `igsttax` float(10,2) NOT NULL,
  `discount` float(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchaseid`, `billingid`, `customerid`, `furnitureid`, `qty`, `cost`, `cgsttax`, `sgsttax`, `igsttax`, `discount`, `status`) VALUES
(10, 12, 12, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, '0.00'),
(11, 13, 12, 18, 1, 14000.00, 12.00, 12.00, 5.00, 0.00, '0.00'),
(12, 14, 11, 17, 2, 22999.00, 12.00, 12.00, 5.00, 5.00, '0.00'),
(13, 15, 11, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, '0.00'),
(14, 16, 11, 20, 1, 44000.00, 12.00, 12.00, 5.00, 0.00, '0.00'),
(15, 17, 11, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, '0.00'),
(16, 18, 11, 18, 1, 14000.00, 12.00, 12.00, 5.00, 0.00, '0.00'),
(17, 0, 0, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, ''),
(18, 20, 11, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(19, 21, 12, 20, 1, 44000.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(20, 22, 13, 21, 2, 18200.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(21, 23, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(22, 24, 13, 18, 1, 14000.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(23, 25, 13, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(24, 26, 13, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(25, 27, 13, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(26, 28, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(27, 29, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(28, 30, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(36, 0, 12, 16, 2, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(38, 0, 12, 16, 2, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(39, 0, 12, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(40, 0, 12, 18, 1, 14000.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(41, 31, 13, 19, 0, 32000.00, 12.00, 12.00, 5.00, 20.00, 'Active'),
(42, 0, 13, 19, 1, 32000.00, 12.00, 12.00, 5.00, 20.00, 'Active'),
(43, 0, 12, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(44, 32, 13, 0, 0, 0.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(45, 33, 13, 0, 0, 0.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(46, 34, 13, 0, 0, 0.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(47, 36, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(48, 36, 13, 17, 2, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(49, 36, 13, 19, 3, 32000.00, 12.00, 12.00, 5.00, 20.00, 'Active'),
(50, 36, 13, 18, 1, 14000.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(51, 36, 13, 18, 4, 14000.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(52, 36, 13, 18, 1, 14000.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(53, 37, 13, 16, 13, 13000.00, 0.00, 0.00, 0.00, 10.00, 'Active'),
(54, 37, 13, 21, 12, 18200.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(55, 38, 13, 17, 1, 30000.00, 0.00, 0.00, 0.00, 5.00, 'Active'),
(56, 38, 13, 17, 1, 30000.00, 0.00, 0.00, 0.00, 5.00, 'Active'),
(57, 38, 13, 16, 1, 13000.00, 0.00, 0.00, 0.00, 10.00, 'Active'),
(59, 39, 13, 17, 1, 30000.00, 0.00, 0.00, 0.00, 5.00, 'Active'),
(60, 40, 12, 17, 2, 30000.00, 0.00, 0.00, 0.00, 5.00, 'Active'),
(61, 40, 12, 24, 4, 4499.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(62, 40, 12, 21, 5, 18200.00, 0.00, 0.00, 0.00, 0.00, 'Active'),
(66, 41, 12, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(67, 41, 12, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(68, 42, 13, 24, 1, 4499.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(69, 42, 13, 24, 1, 4499.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(70, 42, 13, 27, 1, 4500.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(71, 43, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(72, 43, 13, 17, 1, 30000.00, 12.00, 12.00, 5.00, 5.00, 'Active'),
(73, 45, 13, 25, 1, 4999.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(75, 52, 14, 52, 1, 60000.00, 12.00, 12.00, 5.00, 0.00, ''),
(76, 53, 14, 52, 1, 60000.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(77, 54, 14, 52, 1, 60000.00, 12.00, 12.00, 5.00, 0.00, 'Active'),
(78, 55, 12, 36, 1, 44.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(79, 56, 12, 36, 1, 40000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(80, 57, 12, 36, 1, 40000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(81, 58, 12, 43, 1, 20000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(83, 59, 12, 16, 2, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(84, 59, 12, 16, 1, 13000.00, 12.00, 12.00, 5.00, 10.00, 'Active'),
(85, 60, 12, 43, 1, 20000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(86, 61, 12, 43, 1, 20000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(87, 62, 12, 56, 1, 50000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(88, 63, 12, 60, 1, 55000.00, 12.00, 12.00, 0.00, 0.00, 'Active'),
(100, 75, 12, 65, 50, 100000.00, 12.00, 12.00, 0.00, 0.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stockid` int(10) NOT NULL,
  `furnitureid` int(10) NOT NULL,
  `supplierid` int(10) NOT NULL,
  `billno` int(10) NOT NULL,
  `stkdate` date NOT NULL,
  `qty` int(10) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stockid`, `furnitureid`, `supplierid`, `billno`, `stkdate`, `qty`, `cost`, `status`) VALUES
(20, 21, 11, 1230, '2018-02-17', 12, 12000.00, 'Active'),
(21, 21, 11, 234, '2018-01-01', 10, 10.00, 'Active'),
(22, 23, 11, 234, '2018-01-01', 10, 20000.00, 'Active'),
(23, 21, 11, 1210, '2018-02-09', 15, 10000.00, 'Active'),
(24, 16, 12, 1010, '2018-02-10', 10, 10000.00, 'Active'),
(25, 17, 12, 1231, '2018-02-17', 5, 5000.00, 'Active'),
(30, 30, 18, 1111, '2018-02-07', 12, 20000.00, 'Active'),
(32, 16, 12, 156, '2018-02-20', 50, 50000.00, 'Active'),
(36, 25, 12, 414, '2018-02-03', 50, 5000.00, 'Active'),
(37, 21, 11, 700, '2018-02-14', 150, 5000.00, 'Active'),
(38, 26, 11, 700, '2018-02-14', 60, 10000.00, 'Active'),
(39, 29, 11, 700, '2018-02-14', 20, 2000.00, 'Active'),
(40, 20, 12, 7070, '2018-02-24', 100, 6000.00, 'Active'),
(41, 17, 12, 101, '2018-03-24', 100, 6000.00, 'Active'),
(42, 16, 12, 101, '2018-03-24', 100, 6000.00, 'Active'),
(43, 18, 12, 101, '2018-03-24', 100, 6000.00, 'Active'),
(44, 20, 12, 101, '2018-03-24', 100, 6000.00, 'Active'),
(45, 25, 12, 101, '2018-03-24', 100, 600.00, 'Active'),
(46, 19, 13, 102, '2018-03-24', 100, 30000.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplierid` int(10) NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `loginid` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `companylogo` varchar(100) NOT NULL,
  `companydescription` text NOT NULL,
  `companyaddress` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplierid`, `companyname`, `loginid`, `password`, `companylogo`, `companydescription`, `companyaddress`, `city`, `pincode`, `status`) VALUES
(11, 'OmniTechRetailer', 'otr', '111', '', 'All type of furniture and interiors', '3rd floor', 'Manipal', '145581', 'Active'),
(12, 'InStyle', 'insta', '222', '', 'we supply all type of furniture', 'MG Road', 'Bangalore', '574116', 'Active'),
(13, 'Mordern', 'mord', '333', '', 'We supply wooden furniture', '2nd floorBC Road', 'Manglore', '555454', 'Active'),
(15, 'techno', 'techno@techno.com', 'techno', '945824267a8.jpg', 'nil', '', 'test', '8888', 'Active'),
(16, 'Ikea', '', '', '517794343a6.jpg', 'We supply all type of furniture and interiors', 'ikea ', 'Delhi', '25012', 'Active'),
(18, 'samsung', 'sam@gmail.com', 'sam', '1158983702a2.jpg', 'nil', 'nil', 'karnataka', '12345', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `taxid` int(10) NOT NULL,
  `taxtype` varchar(20) NOT NULL,
  `taxpercentage` float(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`taxid`, `taxtype`, `taxpercentage`, `status`) VALUES
(12, 'CGST', 12.00, 'Active'),
(13, 'SGST', 12.00, 'Active'),
(14, 'IGST', 5.00, 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`billingid`);

--
-- Indexes for table `cutomer`
--
ALTER TABLE `cutomer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackid`);

--
-- Indexes for table `furniture`
--
ALTER TABLE `furniture`
  ADD PRIMARY KEY (`furnitureid`);

--
-- Indexes for table `furnitureimages`
--
ALTER TABLE `furnitureimages`
  ADD PRIMARY KEY (`furnitureimgid`);

--
-- Indexes for table `furnituretype`
--
ALTER TABLE `furnituretype`
  ADD PRIMARY KEY (`furnituretypeid`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`messageid`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`offerid`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchaseid`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stockid`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplierid`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`taxid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `billingid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `cutomer`
--
ALTER TABLE `cutomer`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employeeid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `furniture`
--
ALTER TABLE `furniture`
  MODIFY `furnitureid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `furnitureimages`
--
ALTER TABLE `furnitureimages`
  MODIFY `furnitureimgid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `furnituretype`
--
ALTER TABLE `furnituretype`
  MODIFY `furnituretypeid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `messageid` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
  MODIFY `offerid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchaseid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stockid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplierid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
